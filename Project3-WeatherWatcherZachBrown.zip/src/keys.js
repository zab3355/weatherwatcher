exports.weather = {
    key: 'bebf50c1fe49b43d4f6e988de86cc112'
};